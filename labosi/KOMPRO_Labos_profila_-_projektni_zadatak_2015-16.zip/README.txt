SPIN:
Kompletan kod je u izvjescu projektnog zadatka. I kao takav je 100% ispravan. 
Kod simulacije i verifikacije, potrebno je procitati njihove napomene.

CPN:
Problem CPN-a je sto je to sugav program pun bugova i vjerojatno ce te imati problema kod verifikacije. (barem �to se instalacije na windowsu tice)
Prva verifikacija, na mom primjeru mreze traje nekih 5 min, nakon cega se izbaci zuti kvadratic, sto znaci da je CPN obavio djelomican posao, ali na osnovu njega moze napraviti REPORT. Tada, kliknite na zutu oznaku, ona ce se maknuti, te ponovo kliknite za verifikaciju. E, ta druga verifikacija je kod mene trajala cca. sat i pol, nakon cega se pojavi zeleni pravokutnik, sto znaci da je uspjesno zavrsena. Nakon toga mozete raditi ostale stvari. Racunati stanja grafa, report, i crtati graf.
Ako se pojavi crveni pravokutnik, to znaci da je doslo do greske. E sad, ako ste sigurni da je vasa mre�a dobra, onda je vjerojatno bug programa i ne preostaje vam drugo nego bjesomucni restart laptopa i programa, tako dugo dok ne proradi.
Meni je sve radilo navecer skroz normalno, ali u ujutro nisam mogao nista. 
Primjer moje mreze je 100% tocan. Ali bitno je da shvatite kako to funkcionira, pa probajte napraviti sami, cisto zbog ispitivanja i obrana labosa.

ZADATAK:
2 predajnika, 2 prijemnika, 1 mre�a.
Predajnik 1 salje prijemniku 1, a predajnik 2 salje primjeniku 2.
Mogucnost gubitka i paketa (0.5) i potvrde (0.25) + retransmicija.
Slanje paketa nasumicno, a potvrda naizmjenicno.

Goood luck. :)